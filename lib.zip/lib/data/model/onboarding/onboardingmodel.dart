class OnBoradingModel{
  final String? title;
  final String? image;
  final String? body;

  OnBoradingModel(this.title, this.image, this.body);
}