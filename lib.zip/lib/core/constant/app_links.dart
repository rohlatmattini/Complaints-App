class AppLinks {
  // static const String baseUrl = "http://10.0.2.2:8000/api";
static const String baseUrl = "http://10.100.214.88:8000/api";
static const String deviceTokens = "$baseUrl/device-tokens";
// الإشعارات
static const String notifications = '$baseUrl/notifications';
static const String notificationsUnreadCount = '$baseUrl/notifications/unread-count';
static const String notificationsReadAll = '$baseUrl/notifications/read-all';

}


