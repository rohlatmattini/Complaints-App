class AppImageAsset{
  static  String rootImage="assets/images";
  static String onBoardingImageFour="$rootImage/onBoardingImageFour.png";
  static String onBoardingImageOne="$rootImage/onBoardingImageOne.png";
  static String onBoardingImageTwo="$rootImage/onBoardingImageTwo.png";
  static String onBoardingImageThree="$rootImage/onBoardingImageThree.png";
  static String login="$rootImage/login_image.png";
  static String complaintImage="$rootImage/complaints_image.png";
  static String PersonImage="$rootImage/person_image.png";
  static String homePage="$rootImage/person_image.png";
  static String forgetImage="$rootImage/forget_image.png";
  static String emailVeification="$rootImage/email_verification.png";
  static String appLogo="$rootImage/app_logo.png";
}